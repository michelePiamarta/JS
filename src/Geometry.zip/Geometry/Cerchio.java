/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Geometry;

/**
 *
 * @author michele.piamarta
 */
public class Cerchio extends Figura{
    Double raggio;

    public Cerchio(Double raggio, String nome, Punto centro) throws Exception {
        super(nome, centro);
        setRaggio(raggio);
    }
    
    @Override
    public double getArea(){
        return raggio*raggio*Math.PI;
    }
    
    @Override
    public double getPerimetro(){
        return raggio*2*Math.PI;
    }

    public void setRaggio(Double raggio) throws Exception {
        if(raggio <= 0)
            throw new Exception("il raggio non può essere negativo o 0");
        this.raggio = raggio;
    }
    
    
}
