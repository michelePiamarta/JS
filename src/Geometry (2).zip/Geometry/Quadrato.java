/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Geometry;

/**
 *
 * @author michele.piamarta
 */
public class Quadrato extends Rettangolo{
    
    public Quadrato(double lato, String nome, Punto centro){
        super(lato, lato, nome, centro);
    }
    
    public double getArea(){
        return super.getArea();
    }
    
    public double getPerimetro(){
        return super.getPerimetro();
    }

    
    
    
}
